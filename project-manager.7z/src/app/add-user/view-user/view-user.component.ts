import { Component, OnInit, Input, Output } from '@angular/core';
import { User } from 'src/app/add-user/user.model';
import { UserService } from 'src/app/service/user.service';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  @Input() users:User[] = [];
  cacheUserList:User[] = [];
  // @Input() editableUser:User;
  @Output("editableUser") userEmitter: EventEmitter<User> = new EventEmitter<User>();
  searchKey:string = "Search...";
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.getAllUser().subscribe(data => {
      this.users = data;
      this.cacheUserList = this.users;
      this.userService.setLocalUserList(this.users);
    });
  }

  editUser(editableUser:User){
    // this.editableUser = editableUser;
    this.userEmitter.emit(editableUser);
  }

  deleteUser(userToDelete:User){
    if(confirm("Confirm deletion")){
      this.userService.deleteUserById(userToDelete.userId).subscribe( e => {
        const index: number = this.users.indexOf(userToDelete);
        if (index !== -1) {
            this.users.splice(index, 1);
        }
      });
    }
  }

  sortList(criteria:string){
    if(criteria == 'FN'){
      
    }

  }
clearField1(){
    if(this.searchKey == "Search..."){
      this.searchKey = "";
      return;
    }
    
  }
  clearField2(){
    if(this.searchKey == ""){
      this.searchKey = "Search...";
      return;
    }
  }
  searchUserFromList(){
    if(this.searchKey != "" && this.searchKey != "Search..."){
      console.log(this.searchKey);
      let tempUserList:User[] = [];
      for(let user of this.cacheUserList){
        console.log("pushing...");
        if(user.firstName == this.searchKey
            || user.lastName == this.searchKey
            || user.employeeId == this.searchKey
            || user.userId == this.searchKey){
              tempUserList.push(user);
            }
        }
        // this.cacheUserList = this.users;
        this.users = tempUserList;
      }else{
        this.users = this.cacheUserList;
      }
    }
}
